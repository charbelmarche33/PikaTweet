package pikatweet;

import java.util.*;
/**
 * File defines VisableTweetSort class
 * @author Charbel
 */
public class VisibleTweetSort{
    /**
     * This class can take an ArrayList of type Accounts and get all the public tweets, or all the tweets that are visible for a specific user.
     */
    public VisibleTweetSort(){}
    /**
     * Gets all the public tweets form an ArrayList<Accounts> and sorts them so that the latest tweet is put first.
     * @param AllUsers ArrayList of type Accounts that you would like to get all the private tweets from. 
     * @return Returns an ArrayList of type tweet, sorted so that the most recent tweet is first and the oldest is last. 
     */
    public ArrayList<Tweet> getAllPublicTweetsByDate(ArrayList<Accounts> AllUsers){
        allVisibleTweets.clear();
        addAllPublicTweetsToVisible(AllUsers);
        Collections.sort(allVisibleTweets);
        return allVisibleTweets;
    } 
    /**
     * Gets all the visible tweets for a specific user. This includes all public tweets, and the private tweets of the users that the user follows
     * It will have any tweets with an "@<user's username>" at the beginning of the ArrayList and these will be sorted by date. The rest of the tweets 
     * will be after that sorted by date as well.
     * @param AllUser ArrayList of type Accounts that you would like to get all the private tweets from.
     * @param username String of the username of the current user.
     * @return Method returns an ArrayList of all visable tweets ordered so @username is first then the others are by date.
     */
    public ArrayList<Tweet> getAllVisibleTweetsForUser(ArrayList<Accounts> AllUser, String username){
        allVisibleTweets.clear();
        ListIterator<Accounts> iterator = AllUser.listIterator();
        ArrayList<String> followedAccounts = getUsernamesOfPeopleFollowed(AllUser, username);
        ListIterator<String> followingIter = followedAccounts.listIterator();
        while (followingIter.hasNext()){
            String currentUsername = followingIter.next();
            for (int i = 0; i < AllUser.size(); i++){
                if (AllUser.get(i).getUsername().equals(currentUsername)){
                   addAllTweetsOfAccountToVisible(AllUser.get(i), username);
                }
            }
        }
        for (int i = 0; i < AllUser.size(); i++){
                if (AllUser.get(i).getUsername().equals(username)){
                   addAllTweetsOfAccountToVisible(AllUser.get(i), username);
                }
        }
        for(int n = 0; n < AllUser.size(); n++){
            ArrayList<Tweet> allOfUserTweets = AllUser.get(n).getTweetsMadeByUser();
            for (int i = 0; i < allOfUserTweets.size(); i++) {
                if(allOfUserTweets.get(i).getTweetText().contains("@" + username) && !allOfUserTweets.get(i).getUsernameOfTweeter().equals(username)){
                    allVisibleTweets.add(allOfUserTweets.get(i));
                }
            }
        }
        Collections.sort(allVisibleTweets);
        return allVisibleTweets;
    }
    public ArrayList<Tweet> getAllOfUsersTweetsAndAtTweets(ArrayList<Accounts> AllUser, String username){
        for (int i = 0; i < AllUser.size(); i++){
            if (AllUser.get(i).getUsername().equals(username)){
               addAllTweetsOfAccountToVisible(AllUser.get(i), username);
            }
        }
                for(int n = 0; n < AllUser.size(); n++){
            ArrayList<Tweet> allOfUserTweets = AllUser.get(n).getTweetsMadeByUser();
            for (int i = 0; i < allOfUserTweets.size(); i++) {
                if(allOfUserTweets.get(i).getTweetText().contains("@" + username) && !allOfUserTweets.get(i).getUsernameOfTweeter().equals(username)){
                    allVisibleTweets.add(allOfUserTweets.get(i));
                }
            }
        }
        Collections.sort(allVisibleTweets);
        return allVisibleTweets;
    }
    public ArrayList<Tweet> getAllPublicTweetsOfUser(ArrayList<Accounts> AllUser, String username){
        Accounts account = null;
        for(int i = 0; i < AllUser.size(); i++){
            if(AllUser.get(i).getUsername().equals(username)){
                account = AllUser.get(i);
            }
        }
        addPublicTweetsOfAccountToVisible(account);
        Collections.sort(allVisibleTweets);
        return allVisibleTweets;
    }
    private ArrayList<String> getUsernamesOfPeopleFollowed(ArrayList<Accounts> AllUser, String username){
        ListIterator<Accounts> iterator = AllUser.listIterator();
        ArrayList<String> followedAccounts = new ArrayList(0);
        while(iterator.hasNext()){
            Accounts current = iterator.next();
            if(current.getUsername().equals(username)){
                followedAccounts = current.getPeopleFollowed();
            }
        }
        return followedAccounts;
    }
    private void putAtUsernameTweetsFirst(String username){
        int count = allVisibleTweets.size() - 1;
        for (int n = 0; n < allVisibleTweets.size(); n++){
            if(allVisibleTweets.get(n).getTweetText().contains("@" + username) && !allVisibleTweets.get(n).getUsernameOfTweeter().equals(username)){
                allVisibleTweets.add(0, allVisibleTweets.get(n));
                allVisibleTweets.remove(n+1);
                count = count - 1;
                allVisibleTweets.get(n).getTweetText();
                if(n == count){
                    break;
                }
                else{
                    n = n + 1;
                }
            }
        }
    }
    private void addAllPublicTweetsToVisible(ArrayList<Accounts> AllUsers){
        ListIterator<Accounts> iterator = AllUsers.listIterator();
        while(iterator.hasNext()){
            Accounts current = iterator.next();
            addPublicTweetsOfAccountToVisible(current);
        }
    }
    private void addPublicTweetsOfAccountToVisible(Accounts current){
            ArrayList<Tweet> tweet = current.getTweetsMadeByUser();
            ListIterator<Tweet> tweetIter = tweet.listIterator();
            while(tweetIter.hasNext()){
                Tweet currentTweet = tweetIter.next();
                if (currentTweet.isPrivate() == false){
                    allVisibleTweets.add(currentTweet);   
                }
            } 
    }
    private void addAllTweetsOfAccountToVisible(Accounts current, String username){
            ArrayList<Tweet> tweet = current.getTweetsMadeByUser();
            ListIterator<Tweet> tweetIter = tweet.listIterator();
            while(tweetIter.hasNext()){
                Tweet currentTweet = tweetIter.next();
                if(currentTweet.getTweetText().contains("@" + username)){
                    
                }
                else{
                    allVisibleTweets.add(currentTweet);  
                }
            }
    }
    ArrayList<Tweet> allVisibleTweets = new ArrayList(0);
}
