/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pikatweet;

import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Imran
 */
public class FollowingWindow extends javax.swing.JDialog {

    /**
     * Creates new form FollowingWindow
     */
    public FollowingWindow(java.awt.Frame parent, boolean modal, Accounts loggedInAccount) throws IOException, FileNotFoundException, ClassNotFoundException {
        super(parent, modal);
        initComponents();
        LoggedInAccount = loggedInAccount;
        AllOfThePeopleFollowed = LoggedInAccount.getPeopleFollowed();
        AllUsers = fs.retrieveAllUserInfoInUniverse();

        if (AllOfThePeopleFollowed.size() > first) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(first))) {
                    name = AllUsers.get(i).getName();
                }
            }
            firstFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(first) + "<html>";
            FirstFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("1.gif")));
        } else {
            firstFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > second) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(second))) {
                    name = AllUsers.get(i).getName();
                }
            }
            secondFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(second) + "</b>" + "<html>";
            SecondFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("2.gif")));
        } else {
            secondFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > third) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(third))) {
                    name = AllUsers.get(i).getName();
                }
            }
            thirdFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(third) + "</b>" + "<html>";
            ThirdFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("3.gif")));
        } else {
            thirdFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > fourth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fourth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            fourthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fourth) + "</b>" + "<html>";
            FourthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("4.gif")));
        } else {
            fourthFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > fifth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fifth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            fifthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fifth) + "</b>" + "<html>";
            FifthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("5.gif")));
        } else {
            fifthFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > sixth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(sixth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            sixthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(sixth) + "</b>" + "<html>";
            SixthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("6.gif")));
        } else {
            sixthFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > seventh) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(seventh))) {
                    name = AllUsers.get(i).getName();
                }
            }
            seventhFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(seventh) + "</b>" + "<html>";
            SeventhFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("7.gif")));
        } else {
            seventhFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > eigth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(eigth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            eigthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(eigth) + "</b>" + "<html>";
            EigthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("8.gif")));
        } else {
            eigthFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > ninth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(ninth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            ninthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(ninth) + "</b>" + "<html>";
            NinthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("9.gif")));
        } else {
            ninthFollowing = " ";
        }

        if (AllOfThePeopleFollowed.size() > tenth) {
            for (int i = 0; i < AllUsers.size(); i++) {
                if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(tenth))) {
                    name = AllUsers.get(i).getName();
                }
            }
            tenthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(tenth) + "</b>" + "<html>";
            TenthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("10.gif")));
        } else {
            tenthFollowing = " ";
        }

        FirstFollowing.setText(firstFollowing);
        SecondFollowing.setText(secondFollowing);
        ThirdFollowing.setText(thirdFollowing);
        FourthFollowing.setText(fourthFollowing);
        FifthFollowing.setText(fifthFollowing);
        SixthFollowing.setText(sixthFollowing);
        SeventhFollowing.setText(seventhFollowing);
        EigthFollowing.setText(eigthFollowing);
        NinthFollowing.setText(ninthFollowing);
        TenthFollowing.setText(tenthFollowing);

        Caption.setText("People that " + LoggedInAccount.getName() + " follows: ");
        Caption.setFont(new Font("Sans Serif", Font.PLAIN, 15));

        //NumberOfTweetsFound.setText("Number of tweets found: " + TweetsFound.size());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tweet1 = new javax.swing.JLabel();
        tweet2 = new javax.swing.JLabel();
        tweet3 = new javax.swing.JLabel();
        tweet4 = new javax.swing.JLabel();
        tweet5 = new javax.swing.JLabel();
        FifthFollowing = new javax.swing.JLabel();
        ThirdFollowing = new javax.swing.JLabel();
        FirstFollowing = new javax.swing.JLabel();
        SecondFollowing = new javax.swing.JLabel();
        FourthFollowing = new javax.swing.JLabel();
        SixthFollowing = new javax.swing.JLabel();
        TenthFollowing = new javax.swing.JLabel();
        NinthFollowing = new javax.swing.JLabel();
        EigthFollowing = new javax.swing.JLabel();
        SeventhFollowing = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Caption = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        getOlderTweets = new javax.swing.JButton();
        getNewTweets = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        tweet1.setBackground(new java.awt.Color(255, 153, 153));
        tweet1.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        tweet1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tweet1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        tweet1.setOpaque(true);

        tweet2.setBackground(new java.awt.Color(255, 153, 153));
        tweet2.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        tweet2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tweet2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        tweet2.setOpaque(true);
        tweet2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        tweet3.setBackground(new java.awt.Color(255, 153, 153));
        tweet3.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        tweet3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tweet3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        tweet3.setOpaque(true);
        tweet3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        tweet4.setBackground(new java.awt.Color(255, 153, 153));
        tweet4.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        tweet4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tweet4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        tweet4.setOpaque(true);
        tweet4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        tweet5.setBackground(new java.awt.Color(255, 153, 153));
        tweet5.setFont(new java.awt.Font("Lucida Grande", 0, 10)); // NOI18N
        tweet5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tweet5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        tweet5.setOpaque(true);
        tweet5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        FifthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        FifthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        FifthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        FifthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        FifthFollowing.setOpaque(true);
        getContentPane().add(FifthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 210, 40));

        ThirdFollowing.setBackground(new java.awt.Color(255, 153, 153));
        ThirdFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        ThirdFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ThirdFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        ThirdFollowing.setOpaque(true);
        ThirdFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(ThirdFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 210, 40));

        FirstFollowing.setBackground(new java.awt.Color(255, 153, 153));
        FirstFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        FirstFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        FirstFollowing.setOpaque(true);
        FirstFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(FirstFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 210, 40));

        SecondFollowing.setBackground(new java.awt.Color(255, 153, 153));
        SecondFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        SecondFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        SecondFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        SecondFollowing.setOpaque(true);
        SecondFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(SecondFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 210, 40));

        FourthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        FourthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        FourthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        FourthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        FourthFollowing.setOpaque(true);
        FourthFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(FourthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 210, 40));

        SixthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        SixthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        SixthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        SixthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        SixthFollowing.setOpaque(true);
        SixthFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(SixthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 210, 40));

        TenthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        TenthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        TenthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        TenthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TenthFollowing.setOpaque(true);
        getContentPane().add(TenthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 400, 210, 50));

        NinthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        NinthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        NinthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        NinthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        NinthFollowing.setOpaque(true);
        NinthFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(NinthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 360, 210, 40));

        EigthFollowing.setBackground(new java.awt.Color(255, 153, 153));
        EigthFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        EigthFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        EigthFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        EigthFollowing.setOpaque(true);
        EigthFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(EigthFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, 210, 40));

        SeventhFollowing.setBackground(new java.awt.Color(255, 153, 153));
        SeventhFollowing.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        SeventhFollowing.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        SeventhFollowing.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        SeventhFollowing.setOpaque(true);
        SeventhFollowing.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        getContentPane().add(SeventhFollowing, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 280, 210, 40));

        jLabel9.setBackground(new java.awt.Color(255, 0, 0));
        jLabel9.setOpaque(true);
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, 230, 210));

        Caption.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(Caption, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 430, 20));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setOpaque(true);
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 230, 220));

        jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        jLabel12.setOpaque(true);
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 430, 20));

        getOlderTweets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pikatweet/arrow right .png"))); // NOI18N
        getOlderTweets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getOlderTweetsActionPerformed(evt);
            }
        });
        getContentPane().add(getOlderTweets, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, -1, -1));

        getNewTweets.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pikatweet/arrow left.png"))); // NOI18N
        getNewTweets.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getNewTweetsActionPerformed(evt);
            }
        });
        getContentPane().add(getNewTweets, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, -1));

        jLabel10.setBackground(new java.awt.Color(255, 0, 0));
        jLabel10.setOpaque(true);
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 240));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pikatweet/logosmall.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, 90, 30));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 430, 220));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void getOlderTweetsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getOlderTweetsActionPerformed
        if (AllOfThePeopleFollowed.size() <= first + 10) {

        } else {
            first = first + 10;
            second = second + 10;
            third = third + 10;
            fourth = fourth + 10;
            fifth = fifth + 10;
            sixth = sixth + 10;
            seventh = seventh + 10;
            eigth = eigth + 10;
            ninth = ninth + 10;
            tenth = tenth + 10;

            if (AllOfThePeopleFollowed.size() > first) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(first))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                firstFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(first) + "<html>";
                FirstFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("1.gif")));
            } else {
                firstFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > second) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(second))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                secondFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(second) + "</b>" + "<html>";
                SecondFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("2.gif")));
            } else {
                secondFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > third) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(third))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                thirdFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(third) + "</b>" + "<html>";
                ThirdFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("3.gif")));
            } else {
                thirdFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > fourth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fourth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                fourthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fourth) + "</b>" + "<html>";
                FourthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("4.gif")));
            } else {
                fourthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > fifth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fifth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                fifthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fifth) + "</b>" + "<html>";
                FifthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("5.gif")));
            } else {
                fifthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > sixth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(sixth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                sixthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(sixth) + "</b>" + "<html>";
                SixthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("6.gif")));
            } else {
                sixthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > seventh) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(seventh))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                seventhFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(seventh) + "</b>" + "<html>";
                SeventhFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("7.gif")));
            } else {
                seventhFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > eigth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(eigth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                eigthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(eigth) + "</b>" + "<html>";
                EigthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("8.gif")));
            } else {
                eigthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > ninth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(ninth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                ninthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(ninth) + "</b>" + "<html>";
                NinthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("9.gif")));
            } else {
                ninthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > tenth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(tenth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                tenthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(tenth) + "</b>" + "<html>";
                TenthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("10.gif")));
            } else {
                tenthFollowing = " ";
            }

            FirstFollowing.setText(firstFollowing);
            SecondFollowing.setText(secondFollowing);
            ThirdFollowing.setText(thirdFollowing);
            FourthFollowing.setText(fourthFollowing);
            FifthFollowing.setText(fifthFollowing);
            SixthFollowing.setText(sixthFollowing);
            SeventhFollowing.setText(seventhFollowing);
            EigthFollowing.setText(eigthFollowing);
            NinthFollowing.setText(ninthFollowing);
            TenthFollowing.setText(tenthFollowing);

        }
    }//GEN-LAST:event_getOlderTweetsActionPerformed

    private void getNewTweetsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getNewTweetsActionPerformed
        if (first == 0) {

        } else {
            first = first - 10;
            second = second - 10;
            third = third - 10;
            fourth = fourth - 10;
            fifth = fifth - 10;
            sixth = sixth - 10;
            seventh = seventh - 10;
            eigth = eigth - 10;
            ninth = ninth - 10;
            tenth = tenth - 10;

         if (AllOfThePeopleFollowed.size() > first) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(first))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                firstFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(first) + "<html>";
                FirstFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("1.gif")));
            } else {
                firstFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > second) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(second))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                secondFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(second) + "</b>" + "<html>";
                SecondFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("2.gif")));
            } else {
                secondFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > third) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(third))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                thirdFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(third) + "</b>" + "<html>";
                ThirdFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("3.gif")));
            } else {
                thirdFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > fourth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fourth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                fourthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fourth) + "</b>" + "<html>";
                FourthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("4.gif")));
            } else {
                fourthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > fifth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(fifth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                fifthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(fifth) + "</b>" + "<html>";
                FifthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("5.gif")));
            } else {
                fifthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > sixth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(sixth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                sixthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(sixth) + "</b>" + "<html>";
                SixthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("6.gif")));
            } else {
                sixthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > seventh) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(seventh))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                seventhFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(seventh) + "</b>" + "<html>";
                SeventhFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("7.gif")));
            } else {
                seventhFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > eigth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(eigth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                eigthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(eigth) + "</b>" + "<html>";
                EigthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("8.gif")));
            } else {
                eigthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > ninth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(ninth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                ninthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(ninth) + "</b>" + "<html>";
                NinthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("9.gif")));
            } else {
                ninthFollowing = " ";
            }

            if (AllOfThePeopleFollowed.size() > tenth) {
                for (int i = 0; i < AllUsers.size(); i++) {
                    if (AllUsers.get(i).getUsername().equals(LoggedInAccount.getPeopleFollowed().get(tenth))) {
                        name = AllUsers.get(i).getName();
                    }
                }
                tenthFollowing = "<html>" + "<b>" + name + "</b>" + ": " + "@" + LoggedInAccount.getPeopleFollowed().get(tenth) + "</b>" + "<html>";
                TenthFollowing.setIcon(new javax.swing.ImageIcon(getClass().getResource("10.gif")));
            } else {
                tenthFollowing = " ";
            }
            
            FirstFollowing.setText(firstFollowing);
            SecondFollowing.setText(secondFollowing);
            ThirdFollowing.setText(thirdFollowing);
            FourthFollowing.setText(fourthFollowing);
            FifthFollowing.setText(fifthFollowing);
            SixthFollowing.setText(sixthFollowing);
            SeventhFollowing.setText(seventhFollowing);
            EigthFollowing.setText(eigthFollowing);
            NinthFollowing.setText(ninthFollowing);
            TenthFollowing.setText(tenthFollowing);
        }
    }//GEN-LAST:event_getNewTweetsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FollowingWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FollowingWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FollowingWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FollowingWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FollowingWindow dialog = new FollowingWindow(new javax.swing.JFrame(), true, LoggedInAccount);
                    dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                        @Override
                        public void windowClosing(java.awt.event.WindowEvent e) {
                            
                        }
                    });
                    dialog.setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(FollowingWindow.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(FollowingWindow.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Caption;
    private javax.swing.JLabel EigthFollowing;
    private javax.swing.JLabel FifthFollowing;
    private javax.swing.JLabel FirstFollowing;
    private javax.swing.JLabel FourthFollowing;
    private javax.swing.JLabel NinthFollowing;
    private javax.swing.JLabel SecondFollowing;
    private javax.swing.JLabel SeventhFollowing;
    private javax.swing.JLabel SixthFollowing;
    private javax.swing.JLabel TenthFollowing;
    private javax.swing.JLabel ThirdFollowing;
    private javax.swing.JButton getNewTweets;
    private javax.swing.JButton getOlderTweets;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel tweet1;
    private javax.swing.JLabel tweet2;
    private javax.swing.JLabel tweet3;
    private javax.swing.JLabel tweet4;
    private javax.swing.JLabel tweet5;
    // End of variables declaration//GEN-END:variables
    private static ArrayList<String> AllOfThePeopleFollowed;
    private static ArrayList<Accounts> AllUsers = new ArrayList(0);
    private static Accounts LoggedInAccount;
    private static FileStorage fs = new FileStorage();
    private static String name;
    private static int first = 0;
    private static int second = 1;
    private static int third = 2;
    private static int fourth = 3;
    private static int fifth = 4;
    private static int sixth = 5;
    private static int seventh = 6;
    private static int eigth = 7;
    private static int ninth = 8;
    private static int tenth = 9;
    private static String firstFollowing;
    private static String secondFollowing;
    private static String thirdFollowing;
    private static String fourthFollowing;
    private static String fifthFollowing;
    private static String sixthFollowing;
    private static String seventhFollowing;
    private static String eigthFollowing;
    private static String ninthFollowing;
    private static String tenthFollowing;

}
